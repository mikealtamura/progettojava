package soci;
import java.io.Serializable;

public class SocioFinanziatore extends Soci implements Serializable{
	static final long serialVersionUID=1;
	int quotaAggiuntiva;
	
	public SocioFinanziatore (String nome, String cognome) {
		super (nome, cognome);
		this.quota=25000; //quota associativa socio finanziatore
		
	
	}
	
	

}
