package soci;
import java.io.Serializable;

public class SocioOrdinario extends Soci implements Serializable {
	
	static final long serialVersionUID=1;
	
	
	public SocioOrdinario (String nome, String cognome) {
		super (nome, cognome);
		this.quota=5000; //quota associativa socio ordinario
	}

}
