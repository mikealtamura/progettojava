import java.io.*;
import java.util.Vector; 
import soci.*;


public class GestioneDati { 						//contiene il vector lista su cui vengono effettuate tutte le operazioni

	Vector<Soci> lista = new Vector <Soci>();
	protected String fileLista;
	protected String fileBudget;
	private int fondocassa;
	private int ultCod;
	
	
	public GestioneDati (String fileLista, String fileBudget) {				//si occupa del caricamento di fileLista e fileBudget, se esistenti. Altrimenti andr� a crearli
		this.fileLista = fileLista;
		this.fileBudget = fileBudget;
		try {
			ObjectInputStream input = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileLista)));
			lista = (Vector<Soci>) input.readObject();	
			ultCod = (int) input.readInt();
			lista.lastElement().lastCodice = ultCod;	//alla variabile statica lastCodice (ultimo elemento del vector) assegna l'ultimo valore di codice socio presente nel file caricato
			input.close();
		
		} catch (FileNotFoundException e) {      
			System.out.println("file " + fileLista + " non trovato, verr� creato al prossimo salvataggio");

		} catch (ClassNotFoundException e) {
			System.out.println("Errore di lettura");
			System.out.println(e);
		} catch (IOException e) {
			System.out.println("Errore input");
			System.out.println(e);
		}
		try {
			ObjectInputStream inputB = new ObjectInputStream(new BufferedInputStream(new FileInputStream(fileBudget)));
			fondocassa = (int) inputB.readInt();
			inputB.close();
		} catch (FileNotFoundException e) {
			System.out.println("File di budget non trovato, verr� creato al prossimo salvataggio");
		} catch (IOException e) {
			System.out.println("Errore input");
			System.out.println(e);
		}
		
	}
	
	public int getFondocassa() {	
		return this.fondocassa;
	}
	
	public void aggiungiSocio(String nome, String cognome, int n) {		//aggiunge un nuovo socio, permettendo di sceglierne la tipologia
		 // psw gestore
		Soci s = null;
		switch(n) {
		case 1: s = new SocioOrdinario(nome, cognome); break;
		case 2: s = new SocioGestore(nome, cognome); System.out.println("La password � :" +SocioGestore.getPassword());break;
		case 3: s = new SocioFinanziatore(nome, cognome); break;
		}
		lista.add(s);
		return;
		
	}
	
	public void rimuoviSocio(int codiceSocio) {		//rimuove un socio chiedendone il codice
		int cod= codiceOk(codiceSocio);				//controlla l'esistenza del codice socio
		lista.remove(cod);
	}
	
	public void nuovoAnno() {						//azzera le quote associative per il passaggio al nuovo anno
		for (int i = 0; i<lista.size(); i++) {
			lista.get(i).setVersamentoQuota(false);
		}
	}
	
	public void visualizzaElenco() {				//permette di visualizzare l'elenco dei soci (nome, cognome, codice, tipologia)
		for (Soci s : lista ) {
			if (tipologiaSocio(s)==1) System.out.println(s.getNome()+" "+s.getCognome()+" "+s.getCodiceSocio()+" Socio Ordinario");
				else if (tipologiaSocio(s)==2) System.out.println(s.getNome()+" "+s.getCognome()+" "+s.getCodiceSocio()+" Socio Gestore");
					else if (tipologiaSocio(s)==3) System.out.println(s.getNome()+" "+s.getCognome()+" "+s.getCodiceSocio()+" Socio Finanziatore");
			
		}
		
	}
	
	public void visualizzaNonPaganti() {			//permette di visualizzare la lista dei soci che non hanno versato la quota associativa
		for (Soci s : lista) {
			if (s.getVersamentoQuota()==false) {
				System.out.println(s.getNome()+" "+s.getCognome()+" " +s.getCodiceSocio());
			}
		}
	}
	
	public boolean paga(int codiceSocio) { 			//attraverso il codice socio permette di pagare la quota associativa
		int posizione = codiceOk(codiceSocio);
		if (lista.get(posizione).getVersamentoQuota()==false) {
			int q = lista.get(posizione).getQuota();
			fondocassa += q;
			lista.get(posizione).setVersamentoQuota(true);
			return true;
		} else return false;
	}
		
	public boolean aggiuntivo (int codiceSocio, int quotaAggiuntiva) {    //permette di effettuare un versamento aggiuntivo (solo finanziatori e gestori) solo dopo aver pagato la quota associativa
		int posizione = codiceOk(codiceSocio);
		if (lista.get(posizione).getVersamentoQuota()==true) {
			if (tipologiaSocio(lista.get(posizione))==1) {
				System.out.println("Socio Ordinario non abilitato");
				return false;
			} else {
				fondocassa += quotaAggiuntiva;
				return true;
			} 
		} else {
			System.out.println("Il socio non pu� effettuare un versamento aggiuntivo perch� non ha pagato la quota associativa");
			return false;
		}
	}
	
	public boolean spesa (int spesa, String password) {		//permette di effettuare una spesa per la cooperativa (solo gestori)
		boolean spesaok = false;
			if (passwordOk ( password ) == true) {			//controllo input della password (unica per tutti i gestori)
				if (fondocassa>spesa) {
					fondocassa -= spesa;
					spesaok = true;
					return spesaok;
				}
				else {
					System.out.println("Spesa supera budget");
				}
			}  else {
				System.out.println("Password Errata");
			}
		return spesaok;
		
	}

	
	public boolean salvaLista(String nuovoFile) { 		//effettua il salvataggio della lista soci creando un file
		try {
			ObjectOutputStream output = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileLista)));
			output.writeObject(lista);
			ultCod = lista.lastElement().getCodiceSocio();
			output.writeInt(ultCod);
			output.close();
			return true;
		} catch(IOException e) {
			System.out.println("Errore di output");
			System.out.println(e);
			return false;
		}
	}
	
	public boolean salvaBudget(String nuovoFileB) {		//effettua il salvataggio del fondocassa creando un file 
		try {
			ObjectOutputStream output = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(fileBudget)));
			output.writeInt(fondocassa);
			output.close();
			return true;
		} catch(IOException e) {
			System.out.println("Errore di output");
			System.out.println(e);
			return false;
		}
	}
	

	private int tipologiaSocio(Soci s) {		//controlla la tipologia dei soci
		int tipologia = 0;
		if (s instanceof SocioOrdinario) tipologia=1;
			else if (s instanceof SocioGestore) tipologia=2;
				else if (s instanceof SocioFinanziatore) tipologia=3;
		return tipologia;
	}
	
	public boolean passwordOk ( String password) { 	//controlla che la password sia corretta
		return SocioGestore.getPassword().equals(password);
	}
	
	public String visualizzaSocio(int codiceSocio) {	//permette la visualizzazione del socio
		int posizione = codiceOk(codiceSocio);
		return lista.get(posizione).toString();		//override di toString (guardare classe Soci)
	
	}
	private int codiceOk(int codiceSocio) { 	//controlla che il codice socio sia esistente
		int posizione=-1;												
		for (int i = 0; i<lista.size(); i++) {

			if (lista.get(i).getCodiceSocio()==codiceSocio) posizione=i;
		}
		if (posizione==-1) System.out.println("codice socio inesistente");
		return posizione;
		
	}
	
	
	}	
	
	
