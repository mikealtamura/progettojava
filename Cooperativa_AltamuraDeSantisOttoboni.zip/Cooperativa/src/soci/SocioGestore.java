package soci;
import java.io.Serializable;

public class SocioGestore extends Soci implements Serializable{
	
	static final long serialVersionUID=1;
	int quotaAggiuntiva;
	static String password="root"; //password unica per tutti i gestori. Visualizzabile al momento dell'aggiunta di un socio gestore
	
	public SocioGestore (String nome, String cognome) {
		super (nome, cognome);
		this.quota=10000; //quota associativa socio gestore 
		
	}
	
	public static String getPassword() {
		return password;
	}

}
