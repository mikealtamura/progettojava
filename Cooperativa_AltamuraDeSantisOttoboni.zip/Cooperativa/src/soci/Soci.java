package soci;
import java.io.Serializable;

//superclasse a cui si rifanno le sottoclassi SocioGestore, SocioOrdinario e SocioFinanziatore

public class Soci implements Serializable {
	
	static final long serialVersionUID=1; 	//identificatore universale per classe serializzabile
	private String nome;
	private String cognome;
	private int codiceSocio;
	public static int lastCodice = 0;  
	protected int quota;
	private boolean versamentoQuota;
	
	 
	
	
	public Soci (String nome, String cognome) {
		this.nome=nome;
		this.cognome=cognome;
		this.codiceSocio=lastCodice+1;		// riprende il valore statico dell'ultimo codice e effettua un incremento di uno assegnandolo a codiceSocio
		lastCodice++;					
		
		
	}
	
										//qui sotto sono presenti i metodi get e set per l'accesso alle variabili
	public String getNome() {
		return nome;
	}
	
	public String getCognome() {
		return cognome;
	}
	
	public int getCodiceSocio() {
		return codiceSocio;
	}
	
	public boolean getVersamentoQuota() {
		return versamentoQuota;
	}
	
	public int getQuota() {
		return quota;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public void setVersamentoQuota(boolean versamentoQuota) {
		this.versamentoQuota= versamentoQuota;
	}
	
	public String toString () {								//override del metodo toString usato per le stampe dei metodi rimuovi e paga
		return codiceSocio + " " + nome + " " + cognome;
	}
	

}
