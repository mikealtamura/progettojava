import java.util.*;
import java.io.*;
public class Menu {

	public static void main(String[] args) {			//si occupa di caricare i file ed avviare il metodo menup che mostra l'interfaccia del programma
		Scanner input = new Scanner(System.in);
		System.out.println("Carica il file:");
		String fileLista = input.nextLine();
		System.out.println("Carica file budget");
		String fileBudget = input.nextLine();
		GestioneDati soci = new GestioneDati(fileLista, fileBudget);
		menup(fileLista, fileBudget, soci);
		
	}
	public static void menup(String fileLista, String fileBudget, GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		
		int option;
		
		System.out.println("Inserisci un numero da 0 a 11");
		System.out.println("1: Visualizza il budget della cooperativa");
		System.out.println("2: Visualizza elenco soci");
		System.out.println("3: Visualizza elenco soci che non hanno versato la quota associativa");
		System.out.println("4: Aggiungi un socio");
		System.out.println("5: Rimuovi un socio");
		System.out.println("6: Paga quota associativa");
		System.out.println("7: Effettua versamento aggiuntivo (Solo Gestori e Finanziatori)");
		System.out.println("8: Effettua spesa per cooperativa (solo Gestori)");
		System.out.println("9: Passaggio di anno");
		System.out.println("10: Salva elenco soci");
		System.out.println("11: Salva budget");
		System.out.println("0: Esci dal programma");
		
		do {
			option=input.nextInt();
		
			switch (option) {
				case 1: visualizzaFondocassa(soci); break;
				case 2: soci.visualizzaElenco();; break;
				case 3: System.out.println("L'elenco dei soci che non hanno pagato la quota associativa �: ");soci.visualizzaNonPaganti(); break;
				case 4: aggiungiSocioMenu(soci); break;
				case 5: rimuoviSocioMenu(soci); break;
				case 6: pagaMenu(soci); break;
				case 7: aggiuntivoMenu(soci); break;
				case 8: spesaMenu(soci); break;
				case 9: nuovoAnnoMenu(soci); break;
				case 10: salvaListaMenu(soci); break;
				case 11: salvaBudgetMenu(soci); break;
				case 0: System.out.println("Arrivederci");break;
				default: System.out.println("Inserisci un'opzione valida"); break;		
			}
			if (option!=0) {
				System.out.println("Scegli un'altra opzione dal Men�");
			}
		} while (option!=0);
		
		
	}																		// qui sotto abbiamo i metodi richiamati da menup, che al loro interno richiamano i metodi della classe GestioneDati
	public static void visualizzaFondocassa (GestioneDati soci) { 
		System.out.println("Il fondocassa attuale �: " + soci.getFondocassa());
	}
	
	public static void aggiungiSocioMenu(GestioneDati soci) {
		int n;
		Scanner input = new Scanner (System.in);
		System.out.println("Inserisci nome socio: ");
		String nome = input.nextLine();
		System.out.println("Inserisci cognome socio: ");
		String cognome = input.nextLine();
		System.out.println("Scegli tipologia socio: ");
		System.out.println("1: Socio Ordinario");
		System.out.println("2: Socio Gestore");
		System.out.println("3: Socio Finanziatore");
		do {
			n = input.nextInt();
			if (n<1 || n>3) System.out.println("Inserisci opzione valida");			
		} while (n<1 || n>3);
		soci.aggiungiSocio(nome, cognome, n);
		System.out.println("Socio aggiunto");
	} 
	
	public static void rimuoviSocioMenu(GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Inserisci il codice del socio da rimuovere: ");
		int cod = input.nextInt();
		if (cod>soci.lista.size()) {
			System.out.println("Codice socio non presente");
		} else {
		System.out.println("Socio " + soci.visualizzaSocio(cod) + " rimosso");
		soci.rimuoviSocio(cod);
		}
	}
	
	public static void pagaMenu(GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Paga quota associativa");
		System.out.println("Inserisci il codice socio : ");
		int cod = input.nextInt();
		if (cod>soci.lista.size()) {
			System.out.println("Codice socio non presente");
		} else {
			
		if(soci.paga(cod)==false) System.out.println(soci.visualizzaSocio(cod) + " ha gi� pagato la quota associativa");
			else System.out.println("Pagamento effettuato");
		}
	}	
	
	public static void aggiuntivoMenu(GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Inserisci codice socio che effettua il versamento aggiuntivo: "); 
		int cod = input.nextInt();
		if (cod>soci.lista.size()) {
			System.out.println("Codice socio non presente");
		} else {
			System.out.println("Inserisci l'importo aggiuntivo da versare: ");
			int versamento = input.nextInt();
			if (soci.aggiuntivo(cod, versamento)==false) {
			}
			else System.out.println("Il versamento � andato a buon fine");
		
		}
	}	
	
	public static void spesaMenu(GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Inserisci password : ");  //la password � unica, viene mostrata solo ai soci gestori una volta aggiunti.
		String password = input.nextLine();
		System.out.println("Inserisci importo spesa : ");
		int spesa = input.nextInt();
		System.out.println("");
		if(soci.spesa(spesa, password) == false) {
			
		}else System.out.println("Spesa effettuata");
	}
	
	public static void nuovoAnnoMenu(GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Iniziare nuovo anno?");
		System.out.println("1: s�");
		System.out.println("2: no");
		int s = input.nextInt();
		switch (s) {
		case 1: soci.nuovoAnno();System.out.println("Nuovo anno iniziato. Versare nuove quote associative."); break;
		case 2: break;
		default: System.out.println("Scelta non valida"); break;
		}
	}
	
	public static void salvaListaMenu (GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Vuoi salvare la lista?");
		System.out.println("1: s�");
		System.out.println("2: no");
		int s = input.nextInt();
		if (s==1) {
			if (soci.salvaLista(soci.fileLista)) System.out.println("Salvataggio avvenuto correttamente");
			else System.out.println("Errore durante il salvataggio");
		} else if (s==2) System.out.println("Salvataggio non avvenuto");
		else System.out.println("Scegli opzione valida");
	}
	
	public static void salvaBudgetMenu (GestioneDati soci) {
		Scanner input = new Scanner (System.in);
		System.out.println("Vuoi salvare il budget?");
		System.out.println("1: s�");
		System.out.println("2: no");
		int s = input.nextInt();
		if (s==1) {
			if (soci.salvaBudget(soci.fileBudget)) System.out.println("Salvataggio avvenuto correttamente");
			else System.out.println("Errore durante il salvataggio");
		} else if (s==2) System.out.println("Salvataggio non avvenuto");
		else System.out.println("Scegli opzione valida");
	}
	
 }	



